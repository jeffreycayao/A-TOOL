﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Core;
using Microsoft.Office.Interop.Outlook;

using OutlookApp = Microsoft.Office.Interop.Outlook.Application;

namespace WindowsFormsApplication1
{
    public partial class SysUpgradeNotif : Form
    {
        string msg = "";
        

        public SysUpgradeNotif()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            msg = txtTitle.Text;
            OutlookApp outlookApp = new OutlookApp();
            MailItem mailItem = outlookApp.CreateItem(OlItemType.olMailItem);

            mailItem.To = "support@gdriveph.com"; // Set recipient
            mailItem.Subject = txtTitle.Text;
            mailItem.CC = "";
            mailItem.HTMLBody = @"
                        <!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
                        <html dir='ltr' xmlns='http://www.w3.org/1999/xhtml' xmlns:o='urn:schemas-microsoft-com:office:office' lang='en' style='padding:0;Margin:0'>
                         <head>
                          <meta charset='UTF-8'>
                          <meta content='width=device-width, initial-scale=1' name='viewport'>
                          <meta name='x-apple-disable-message-reformatting'>
                          <meta http-equiv='X-UA-Compatible' content='IE=edge'>
                          <meta content='telephone=no' name='format-detection'>
                          <title>Important System Upgrade Notice: Action Required</title><!--[if (mso 16)]>
                            <style type='text/css'>
                            a {text-decoration: none;}
                            </style>
                            <![endif]--><!--[if gte mso 9]><style>sup { font-size: 100% !important; }</style><![endif]--><!--[if gte mso 9]>
                        <xml>
                            <o:OfficeDocumentSettings>
                            <o:AllowPNG></o:AllowPNG>
                            <o:PixelsPerInch>96</o:PixelsPerInch>
                            </o:OfficeDocumentSettings>
                        </xml>
                        <![endif]--><!--[if !mso]><!-- -->
                          <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700,700i' rel='stylesheet'>
                          <link href='https://fonts.googleapis.com/css?family=Roboto:400,400i,700,700i' rel='stylesheet'>
                          <link href='https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400i,700,700i' rel='stylesheet'><!--<![endif]-->
                          <style type='text/css'>
                        .rollover span {
	                        font-size:0;
                        }
                        .rollover:hover .rollover-first {
	                        max-height:0px!important;
	                        display:none!important;
                        }
                        .rollover:hover .rollover-second {
	                        max-height:none!important;
	                        display:inline-block!important;
                        }
                        #outlook a {
	                        padding:0;
                        }
                        .ExternalClass {
	                        width:100%;
                        }
                        .ExternalClass,
                        .ExternalClass p,
                        .ExternalClass span,
                        .ExternalClass font,
                        .ExternalClass td,
                        .ExternalClass div {
	                        line-height:100%;
                        }
                        .es-button {
	                        mso-style-priority:100!important;
	                        text-decoration:none!important;
                        }
                        a[x-apple-data-detectors] {
	                        color:inherit!important;
	                        text-decoration:none!important;
	                        font-size:inherit!important;
	                        font-family:inherit!important;
	                        font-weight:inherit!important;
	                        line-height:inherit!important;
                        }
                        .es-desk-hidden {
	                        display:none;
	                        float:left;
	                        overflow:hidden;
	                        width:0;
	                        max-height:0;
	                        line-height:0;
	                        mso-hide:all;
                        }
                        .es-button-border:hover a.es-button, .es-button-border:hover button.es-button {
	                        background:#056dff!important;
                        }
                        .es-button-border:hover {
	                        border-color:#056dff #056dff #056dff #056dff!important;
	                        background:#056dff!important;
	                        border-style:solid solid solid solid!important;
                        }
                        @media only screen and (max-width:600px) {p, ul li, ol li, a { line-height:100%!important } h1, h2, h3, h1 a, h2 a, h3 a { line-height:120% } h1 { font-size:26px!important; text-align:left } h2 { font-size:22px!important; text-align:left } h3 { font-size:18px!important; text-align:left } h1 a { text-align:left } .es-header-body h1 a, .es-content-body h1 a, .es-footer-body h1 a { font-size:26px!important } h2 a { text-align:left } .es-header-body h2 a, .es-content-body h2 a, .es-footer-body h2 a { font-size:22px!important } h3 a { text-align:left } .es-header-body h3 a, .es-content-body h3 a, .es-footer-body h3 a { font-size:18px!important } .es-menu td a { font-size:12px!important } .es-header-body p, .es-header-body ul li, .es-header-body ol li, .es-header-body a { font-size:12px!important } .es-content-body p, .es-content-body ul li, .es-content-body ol li, .es-content-body a { font-size:14px!important } .es-footer-body p, .es-footer-body ul li, .es-footer-body ol li, .es-footer-body a { font-size:12px!important } .es-infoblock p, .es-infoblock ul li, .es-infoblock ol li, .es-infoblock a { font-size:12px!important } *[class='gmail-fix'] { display:none!important } .es-m-txt-c, .es-m-txt-c h1, .es-m-txt-c h2, .es-m-txt-c h3 { text-align:center!important } .es-m-txt-r, .es-m-txt-r h1, .es-m-txt-r h2, .es-m-txt-r h3 { text-align:right!important } .es-m-txt-l, .es-m-txt-l h1, .es-m-txt-l h2, .es-m-txt-l h3 { text-align:left!important } .es-m-txt-r img, .es-m-txt-c img, .es-m-txt-l img { display:inline!important } .es-button-border { display:inline-block!important } a.es-button, button.es-button { font-size:12px!important; display:inline-block!important } .es-btn-fw { border-width:10px 0px!important; text-align:center!important } .es-adaptive table, .es-btn-fw, .es-btn-fw-brdr, .es-left, .es-right { width:100%!important } .es-content table, .es-header table, .es-footer table, .es-content, .es-footer, .es-header { width:100%!important; max-width:600px!important } .es-adapt-td { display:block!important; width:100%!important } .adapt-img { width:100%!important; height:auto!important } .es-m-p0 { padding:0!important } .es-m-p0r { padding-right:0!important } .es-m-p0l { padding-left:0!important } .es-m-p0t { padding-top:0!important } .es-m-p0b { padding-bottom:0!important } .es-m-p20b { padding-bottom:20px!important } .es-m-p10b { padding-bottom:10px!important } .es-m-p20r { padding-right:20px!important } .es-mobile-hidden, .es-hidden { display:none!important } tr.es-desk-hidden, td.es-desk-hidden, table.es-desk-hidden { width:auto!important; overflow:visible!important; float:none!important; max-height:inherit!important; line-height:inherit!important } tr.es-desk-hidden { display:table-row!important } table.es-desk-hidden { display:table!important } td.es-desk-menu-hidden { display:table-cell!important } table.es-table-not-adapt, .esd-block-html table { width:auto!important } table.es-social { display:inline-block!important } table.es-social td { display:inline-block!important } .es-desk-hidden { display:table-row!important; width:auto!important; overflow:visible!important; max-height:inherit!important } .es-m-margin { padding-left:10px!important; padding-right:10px!important; padding-top:5px!important; padding-bottom:5px!important } .es-m-p5 { padding:5px!important } .es-m-p5t { padding-top:5px!important } .es-m-p5b { padding-bottom:5px!important } .es-m-p5r { padding-right:5px!important } .es-m-p5l { padding-left:5px!important } .es-m-p10 { padding:10px!important } .es-m-p10t { padding-top:10px!important } .es-m-p10r { padding-right:10px!important } .es-m-p10l { padding-left:10px!important } .es-m-p15 { padding:15px!important } .es-m-p15t { padding-top:15px!important } .es-m-p15b { padding-bottom:15px!important } .es-m-p15r { padding-right:15px!important } .es-m-p15l { padding-left:15px!important } .es-m-p20 { padding:20px!important } .es-m-p20t { padding-top:20px!important } .es-m-p20l { padding-left:20px!important } .es-m-p25 { padding:25px!important } .es-m-p25t { padding-top:25px!important } .es-m-p25b { padding-bottom:25px!important } .es-m-p25r { padding-right:25px!important } .es-m-p25l { padding-left:25px!important } .es-m-p30 { padding:30px!important } .es-m-p30t { padding-top:30px!important } .es-m-p30b { padding-bottom:30px!important } .es-m-p30r { padding-right:30px!important } .es-m-p30l { padding-left:30px!important } .es-m-p35 { padding:35px!important } .es-m-p35t { padding-top:35px!important } .es-m-p35b { padding-bottom:35px!important } .es-m-p35r { padding-right:35px!important } .es-m-p35l { padding-left:35px!important } .es-m-p40 { padding:40px!important } .es-m-p40t { padding-top:40px!important } .es-m-p40b { padding-bottom:40px!important } .es-m-p40r { padding-right:40px!important } .es-m-p40l { padding-left:40px!important } }
                        @media screen and (max-width:384px) {.mail-message-content { width:414px!important } }
                        </style>
                         </head>
                         <body style='width:100%;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;-webkit-text-size-adjust:100%;-ms-text-size-adjust:100%;padding:0;Margin:0'>
                          <div style='display:none !important;font-size:0px;line-height:0;color:#ffffff;visibility:hidden;opacity:0;height:0;width:0;mso-hide:all'>
                           We are writing to inform you of an upcoming system upgrade that is part of our commitment to providing the best service and maintaining a high level of security and performance. This upgrade is essential for enhancing our system's capabilities and ensuring its reliability.
                          </div>
                          <div dir='ltr' class='es-wrapper-color' lang='en' style='background-color:#E1E6F4'><!--[if gte mso 9]>
			                        <v:background xmlns:v='urn:schemas-microsoft-com:vml' fill='t'>
				                        <v:fill type='tile' color='#e1e6f4'></v:fill>
			                        </v:background>
		                        <![endif]-->
                           <table class='es-wrapper' width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;padding:0;Margin:0;width:100%;height:100%;background-repeat:repeat;background-position:center top;background-color:#E1E6F4'>
                             <tr style='border-collapse:collapse'>
                              <td class='es-m-margin' valign='top' style='padding:0;Margin:0'>
                               <table class='es-header' cellspacing='0' cellpadding='0' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top'>
                                 <tr style='border-collapse:collapse'>
                                  <td align='center' style='padding:0;Margin:0'>
                                   <table class='es-header-body' cellspacing='0' cellpadding='0' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#0057B8;width:600px'>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' bgcolor='#0057b8' style='padding:0;Margin:0;background-color:#0057b8'>
                                       <table cellspacing='0' cellpadding='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p0r' align='center' style='padding:0;Margin:0;width:600px'>
                                           <table width='100%' cellspacing='0' cellpadding='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' style='padding:0;Margin:0;font-size:0px'><a target='_blank' href='https://insurance.archgroup.com/' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#FFFFFF;font-size:14px'><img src='https://fehebuv.stripocdn.email/content/guids/CABINET_81344a643c856d4b495773ee2772277febb244790f54a19c54a82531a544e4f8/images/notice.png' alt style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic' class='adapt-img' width='600'></a></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                   </table></td>
                                 </tr>
                               </table>
                               <table class='es-content' cellspacing='0' cellpadding='0' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%'>
                                 <tr style='border-collapse:collapse'>
                                  <td align='center' style='padding:0;Margin:0'>
                                   <table class='es-content-body' cellspacing='0' cellpadding='0' align='center' bgcolor='#ffffff' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#FFFFFF;width:600px'>
                                     <tr style='border-collapse:collapse'>
                                      <td class='esdev-adapt-off' align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' bgcolor='#0057b8' style='padding:0;Margin:0'><h1 style='Margin:0;line-height:31px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:26px;font-style:normal;font-weight:normal;color:#ffffff'><strong>"+txtTitle.Text +@"</strong></h1></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:250px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-left' align='left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:250px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' background='https://fehebuv.stripocdn.email/content/guids/CABINET_ce9fd47f3d3738833e96127769b97842/images/65701593513374751.png' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-image:url(https://fehebuv.stripocdn.email/content/guids/CABINET_ce9fd47f3d3738833e96127769b97842/images/65701593513374751.png);background-repeat:no-repeat;background-position:center center;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' style='padding:0;Margin:0;font-size:0px' height='270'><a target='_blank' class='rollover' href='' style='-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;text-decoration:underline;color:#2CB543;font-size:14px'><img src='https://fehebuv.stripocdn.email/content/guids/CABINET_81344a643c856d4b495773ee2772277febb244790f54a19c54a82531a544e4f8/images/acgld.png' alt style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic' width='128' class='rollover-first'><span style='font-size:0;mso-hide:all'><img width='128' class='rollover-second' style='display:none;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic;max-height:0px' src='https://fehebuv.stripocdn.email/content/guids/CABINET_81344a643c856d4b495773ee2772277febb244790f54a19c54a82531a544e4f8/images/acgl.png' alt></span></a></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:40px'></td><td style='width:250px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:250px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-width:1px;border-style:solid;border-color:#e7eaf3;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' style='Margin:0;padding-left:5px;padding-right:5px;padding-top:15px;padding-bottom:15px'><img class='adapt-img' alt='timer' title='timer' width='238' src='https://cdt-timer.stripocdn.email/api/v1/images/TOeJ46-M9QoN71TydX564wki1pLMg1xXGvRyoxsnh_Y?token=963f3856-8739-4b6f-8576-fd92063152ff&amp;l=1707241204572' style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic'></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:250px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0;padding-top:20px'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#000101;font-size:14px'>We are writing to inform you of an upcoming system upgrade that is part of our commitment to providing the best service and maintaining a high level of security and performance. This upgrade is essential for enhancing our system's capabilities and ensuring its reliability.&nbsp;<strong> "+txtSummary.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td class='esdev-adapt-off' align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' bgcolor='#0057b8' style='padding:0;Margin:0'><h1 style='Margin:0;line-height:31px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:26px;font-style:normal;font-weight:normal;color:#ffffff'><strong>Upgrade Details</strong></h1></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Purpose of the Upgrade:</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>The upcoming upgrade will introduce new features, improve system security, and enhance overall performance. This is a crucial step in our ongoing efforts to improve your user experience and protect your data.&nbsp;<strong>"+txtu_PurposeOfUpgrade.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Date and Time:</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>The upgrade is scheduled for [Date], starting from [Time] and is expected to last approximately [Duration]. Please note that the times are in [Time Zone].&nbsp;<strong>"+txtu_dateandtime.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Expected Duration:</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>We anticipate the system will be unavailable/in maintenance mode for approximately [Duration]. We have chosen this schedule to minimize the impact on our users as much as possible.&nbsp;<strong>"+txtu_expectedduration.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td class='esdev-adapt-off' align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' bgcolor='#0057b8' style='padding:0;Margin:0'><h1 style='Margin:0;line-height:31px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:26px;font-style:normal;font-weight:normal;color:#ffffff'><strong>Impact on Users</strong></h1></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>System Downtime</strong>:</p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>During the upgrade, [specify systems or services] will be temporarily unavailable. We recommend completing any critical tasks that require these systems before the upgrade begins.&nbsp;<strong>"+txtI_systemdowntime.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Workaround Plans</strong>:</p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>For essential services, you can [describe any alternative access methods or temporary solutions] during the upgrade period.&nbsp;<strong>"+txti_workaroudplans.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td class='esdev-adapt-off' align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' bgcolor='#0057b8' style='padding:0;Margin:0'><h1 style='Margin:0;line-height:31px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:26px;font-style:normal;font-weight:normal;color:#ffffff'><strong>Action Required</strong>:<strong></strong></h1></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Preparation Steps:</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>Please ensure that you [list any necessary actions users need to take, such as saving work or logging out of the system] before the upgrade starts.&nbsp;<strong>"+txta_preparationsteps.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Post-Upgrade Actions</strong>:</p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>After the upgrade, users may need to [update passwords, download new software, etc.]. Detailed instructions will be provided as needed.&nbsp;<strong>"+txta_PostUpgradeActions.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                   </table></td>
                                 </tr>
                               </table>
                               <table cellpadding='0' cellspacing='0' class='es-content' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%'>
                                 <tr style='border-collapse:collapse'>
                                  <td align='center' style='padding:0;Margin:0'>
                                   <table class='es-content-body' align='center' cellpadding='0' cellspacing='0' bgcolor='#ffffff' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#FFFFFF;width:600px'>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='center' valign='top' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' bgcolor='#0057b8' style='padding:0;Margin:0'><h1 style='Margin:0;line-height:31px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:26px;font-style:normal;font-weight:normal;color:#ffffff'><strong>Testing Needed</strong>: Yes/No<strong></strong></h1></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Testing Window Time:</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>Testing will be conducted from [Start Date/Time] to [End Date/Time]. Your participation in testing specific functionalities [mention any particular focus, if applicable] will be invaluable.<strong>"+txtT_TestingWindow.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Testing Instructions:</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>Detailed testing instructions will be provided [mention how and when they will be provided].<strong>"+txtt_TestingInstructions.Text+@"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-bottom:20px;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:176px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' align='left' class='es-left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:176px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#0057b8;font-size:14px'><strong>Feedback Submission</strong>:</p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:344px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:344px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:roboto, 'helvetica neue', helvetica, arial, sans-serif;line-height:17px;color:#666666;font-size:14px'>Please report any issues or feedback through [how they should submit feedback, e.g., a specific form, email, or system].<strong>"+txtT_FeedbackSubmissions.Text+ @"</strong></p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='center' valign='top' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' bgcolor='#0057b8' style='padding:0;Margin:0'><h1 style='Margin:0;line-height:31px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:26px;font-style:normal;font-weight:normal;color:#ffffff'><strong>Support Information</strong></h1></td>
                                             </tr>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#666666;font-size:14px'><br></p><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#666666;font-size:14px'>For any questions or concerns, please do not hesitate to contact our IT support team at [Email Address] or [Phone Number].</p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:260px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-left' align='left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='center' valign='top' style='padding:0;Margin:0;width:260px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-width:1px;border-style:solid;border-color:#e7eaf3;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td style='Margin:0;padding-top:5px;padding-bottom:5px;padding-left:15px;padding-right:15px'>
                                               <table width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                 <tr style='border-collapse:collapse'>
                                                  <td style='padding:0;Margin:0;width:50px;font-size:0px'><img src='https://fehebuv.stripocdn.email/content/guids/CABINET_13423afda558880ded79189b9660a694/images/1071580310750158.png' alt='123' style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic' width='50'></td>
                                                  <td style='padding:0;Margin:0;width:10px'></td>
                                                  <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#333333;font-size:14px'>AMIS eNOC</p><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#666666;font-size:14px'><strong>Major Incident Mgmt.</strong></p></td>
                                                 </tr>
                                               </table></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:260px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='center' valign='top' style='padding:0;Margin:0;width:260px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-width:1px;border-style:solid;border-color:#e7eaf3;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td style='Margin:0;padding-top:5px;padding-bottom:5px;padding-left:15px;padding-right:15px'>
                                               <table width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                 <tr style='border-collapse:collapse'>
                                                  <td style='padding:0;Margin:0;width:50px;font-size:0px'><img src='https://fehebuv.stripocdn.email/content/guids/CABINET_13423afda558880ded79189b9660a694/images/1071580310750158.png' alt='123' style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic' width='50'></td>
                                                  <td style='padding:0;Margin:0;width:10px'></td>
                                                  <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#333333;font-size:14px'>Jeffrey Cayao</p><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#666666;font-size:14px'><b>AIGI ITSM</b></p></td>
                                                 </tr>
                                               </table></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='center' valign='top' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' bgcolor='#0057b8' style='padding:0;Margin:0'><h1 style='Margin:0;line-height:31px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:26px;font-style:normal;font-weight:normal;color:#ffffff'><strong>Attachments </strong></h1></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'><!--[if mso]><table style='width:540px' cellpadding='0' cellspacing='0'><tr><td style='width:260px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-left' align='left' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:left'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:260px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:21px;color:#666666;font-size:14px'>Please update the attached file.</p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td><td style='width:20px'></td><td style='width:260px' valign='top'><![endif]-->
                                       <table cellpadding='0' cellspacing='0' class='es-right' align='right' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;float:right'>
                                         <tr style='border-collapse:collapse'>
                                          <td class='es-m-p20b' align='left' style='padding:0;Margin:0;width:260px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:separate;border-spacing:0px;border-width:1px;border-style:solid;border-color:#e7eaf3;border-radius:8px;background-color:#ffffff' bgcolor='#ffffff'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' style='Margin:0;padding-left:15px;padding-right:15px;padding-top:20px;padding-bottom:20px;font-size:0px'><img src='https://fehebuv.stripocdn.email/content/guids/CABINET_81344a643c856d4b495773ee2772277febb244790f54a19c54a82531a544e4f8/images/klipartzcom_1.png' alt style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic' width='100'></td>
                                             </tr>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0;padding-left:15px;padding-right:15px;padding-top:30px'><h3 style='Margin:0;line-height:22px;mso-line-height-rule:exactly;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-size:18px;font-style:normal;font-weight:normal;color:#333333'>Upgrade Activity File</h3></td>
                                             </tr>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0;padding-top:10px;padding-left:15px;padding-right:15px'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#666666;font-size:14px'>Date Modified: Today</p></td>
                                             </tr>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='Margin:0;padding-top:15px;padding-bottom:15px;padding-left:15px;padding-right:15px'><!--[if mso]><a href='" + txtAttachmentLink.Text + @"' target='_blank' hidden>
	                        <v:roundrect xmlns:v='urn:schemas-microsoft-com:vml' xmlns:w='urn:schemas-microsoft-com:office:word' esdevVmlButton href='#' 
                                        style='height:48px; v-text-anchor:middle; width:222px' arcsize='21%' strokecolor='#388cff' strokeweight='3px' fillcolor='#388cff'>
		                        <w:anchorlock></w:anchorlock>
		                        <center style='color:#ffffff; font-family:arial, 'helvetica neue', helvetica, sans-serif; font-size:12px; font-weight:700; line-height:12px;  mso-text-raise:1px'><a href=" + txtAttachmentLink.Text + @">CHECK FILE HERE</a></center>
	                        </v:roundrect></a>
                        <![endif]--><!--[if !mso]><!-- 0 --><!--[if !mso]><!-- --><span class='msohide es-button-border' style='border-style:solid;border-color:#388CFF;background:#388cff;border-width:3px;display:inline-block;border-radius:10px;width:auto;mso-hide:all'><a href='#' class='es-button' style='mso-style-priority:100 !important;text-decoration:none;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;color:#FFFFFF;font-size:12px;display:inline-block;background:#388CFF;border-radius:10px;font-family:arial, 'helvetica neue', helvetica, sans-serif;font-weight:bold;font-style:normal;line-height:14px;width:auto;text-align:center;padding:10px 25px 10px 25px;mso-padding-alt:0;mso-border-alt:10px solid #388CFF'>Update File [INPUT FORM - LINK]</a></span><!--<![endif]--><!--<![endif]--></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table><!--[if mso]></td></tr></table><![endif]--></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='center' valign='top' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#666666;font-size:14px'>We appreciate your understanding and cooperation as we work to improve our systems. Your support in these efforts, including participating in post-upgrade testing where applicable, is crucial to ensuring a smooth transition and the best possible service.</p><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'open sans', 'helvetica neue', helvetica, arial, sans-serif;line-height:14px;color:#666666;font-size:14px'><br></p></td>
                                             </tr>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' style='padding:20px;Margin:0;font-size:0'>
                                               <table border='0' width='100%' height='100%' cellpadding='0' cellspacing='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                 <tr style='border-collapse:collapse'>
                                                  <td style='padding:0;Margin:0;border-bottom:1px solid #cccccc;background:unset;height:1px;width:100%;margin:0px'></td>
                                                 </tr>
                                               </table></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                   </table></td>
                                 </tr>
                               </table>
                               <table cellpadding='0' cellspacing='0' class='es-footer' align='center' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;table-layout:fixed !important;width:100%;background-color:transparent;background-repeat:repeat;background-position:center top'>
                                 <tr style='border-collapse:collapse'>
                                  <td align='center' style='padding:0;Margin:0'>
                                   <table class='es-footer-body' align='center' cellpadding='0' cellspacing='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px;background-color:#0057B8;width:600px'>
                                     <tr style='border-collapse:collapse'>
                                      <td class='esdev-adapt-off' align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td class='es-m-txt-c' align='center' style='padding:0;Margin:0;font-size:0px'><img src='https://fehebuv.stripocdn.email/content/guids/CABINET_81344a643c856d4b495773ee2772277febb244790f54a19c54a82531a544e4f8/images/acgl_bigd.png' alt style='display:block;border:0;outline:none;text-decoration:none;-ms-interpolation-mode:bicubic' width='98'></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='padding:0;Margin:0;padding-top:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='left' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' class='es-m-txt-l' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'source sans pro', 'helvetica neue', helvetica, arial, sans-serif;line-height:12px;color:#EFEFEF;font-size:12px'>FOR INTERNAL USE ONLY:&nbsp;<b>©</b> 2024 Arch Capital Group LTD. All Rights Reserved&nbsp;</p></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                     <tr style='border-collapse:collapse'>
                                      <td align='left' style='Margin:0;padding-top:20px;padding-bottom:30px;padding-left:30px;padding-right:30px'>
                                       <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                         <tr style='border-collapse:collapse'>
                                          <td align='center' valign='top' style='padding:0;Margin:0;width:540px'>
                                           <table cellpadding='0' cellspacing='0' width='100%' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' style='padding:20px;Margin:0;font-size:0'>
                                               <table border='0' width='100%' height='100%' cellpadding='0' cellspacing='0' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                 <tr style='border-collapse:collapse'>
                                                  <td style='padding:0;Margin:0;border-bottom:1px solid #cccccc;background:unset;height:1px;width:100%;margin:0px'></td>
                                                 </tr>
                                               </table></td>
                                             </tr>
                                             <tr style='border-collapse:collapse'>
                                              <td align='center' class='es-m-txt-c' style='padding:0;Margin:0'>
                                               <table class=' cke_show_border' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                 <tr style='border-collapse:collapse'>
                                                  <td style='padding:0;Margin:0'>
                                                   <table class=' cke_show_border' style='mso-table-lspace:0pt;mso-table-rspace:0pt;border-collapse:collapse;border-spacing:0px'>
                                                     <tr style='border-collapse:collapse'>
                                                      <td align='left' style='padding:0;Margin:0'><p style='Margin:0;-webkit-text-size-adjust:none;-ms-text-size-adjust:none;mso-line-height-rule:exactly;font-family:'source sans pro', 'helvetica neue', helvetica, arial, sans-serif;line-height:12px;color:#EFEFEF;font-size:12px;text-align:center'>You're receiving this email for updates on system upgrades that may impact your service use. If you wish to opt-out of future notices, please <a href='mailto:jcayao@achgroup.com?subject=Unsubscribe%20Request&body=Hi%20Jay%2C%20%0D%0A%0D%0AKindly%20Unsubscribe%20me%20from%20all%20future%20communications.%20Thank%20you!'>Unsubscribe</a></a></p></td>
                                                   </table></td>
                                                 </tr>
                                               </table></td>
                                             </tr>
                                           </table></td>
                                         </tr>
                                       </table></td>
                                     </tr>
                                   </table></td>
                                 </tr>
                               </table>
                          </div>
                         </body>
                        </html>";

            //Set a high priority to the message
            mailItem.Importance = OlImportance.olImportanceHigh;
            mailItem.Display(true);
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
